YUUNITETSU 502SE SERIES

This model file 502SE(DEMO) is an add-on for Minecraft Transit Railway. According to our promise, This model is distributed in Minecraft Transit Railway's DISCORD, if you find this readme file in other places, it will prove someone broke their promise.

If you need submit an issue, Mail > Santorsia@Santorsia.net


This model file is provided under the Creative Commons Agreement (CC Attribution), but there are three requirements:

1. It shall not be used for actual commercial purposes and in the promotion of other servers;

2. Do not take the original model as your own(works);

3. Do not redistribute or even sell the original file of the car body model;


本模型 502SE Series(DEMO) 乃 SantorsiaWorks 製作 MTR 模組專用的附加組件。據 「悠日計畫 第三方披露分享法案」 ，將車體公開配布于 Minecraft Transit Railway's DISCORD ，若您在他地尋得此自述文件即證侵權。

如若您需要協助或提交 issue，Mail > Santorsia@Santorsia.net


本模型文件遵循知識共享協議(CC Attribution)提供，但有三點要求：

1.不得用於現實商業用途及他者伺服器宣傳中；

2.不得將車體模型原始文件據爲己有；

3.不得二次分發乃至售賣車體模型原始文件；


このモデル YUUNITETSU 502SE(DEMO) SERIES は Minecraft Transit Railway のアドオンです。 私たちの約束によると、このモデルは Minecraft Transit Railway の DISCORD で配布されています。この readme ファイルが他の場所で見つかった場合、誰かが約束を破ったことが証明されます。

問題を提出する必要がある場合は、> Santorsia@Santorsia.net


このモデル ファイルは CC Attribution の下で提供されますが、3 つの要件があります。

1. 実際の商業目的および他のServerの宣伝に使用しないこと。

2. 元のモデルを自分のものとして使用しないでください

3. 車体モデルのオリジナルファイルを再配布したり、販売したりしないでください。





